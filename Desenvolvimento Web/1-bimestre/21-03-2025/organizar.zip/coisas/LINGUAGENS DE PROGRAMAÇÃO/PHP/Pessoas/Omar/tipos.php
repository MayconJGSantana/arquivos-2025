<?php

$n1 = 23.4;
$n2 = 11;
$soma = $n1 + $n2;

echo "a soma de $n1 + $n2 é igual a $soma \n";

echo "a soma de n1 + n2 é igual: " . $soma . "\n";
//concantenamos pois alguns programas não aceitam a união de variáveis dentre textos simples

 $tipo = gettype($soma);
 //gettype pega o tipo do informado

 echo $tipo . "\n";




