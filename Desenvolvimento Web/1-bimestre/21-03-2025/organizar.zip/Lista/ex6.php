<?php

$primeiro_numero = (int) readline("Entre com um número: ");

$segundo_numero = (int) readline("Entre com um número: ");

for ($i = 0; $i < $wsegundo)