<?php

class Pokemon {

    public $nome;
    public $atributo;
    public $experiencia;
    public $pontosVida;
    public $ataque;
    public $defesa;
    public $velocidade;

    
    function __construct($nome) {
        $this -> nome = $nome;

    }


    function batalhar() {

    }

    function usarPocoes() {

    }

    function aumentaExperiencia() {

    }

}




$caminho = 'National-Pokedex-Gen-9.csv';

$teste = file($caminho);

$testao = str_getcsv($teste[0]);

var_dump($testao);

