<?php

class Pessoa {


    // Atributos

    private $nome;
    private $endereco;
    private $cidade;
    private $uf;
    private $altura;


    // Métodos

    public function getApresentacao() {

        return "Olá mundo, sou " . $this -> nome . ", resido no endereço " . $this -> endereco . ", " . $this -> cidade . "-" . $this -> uf . " e possuo uma altura de " . $this -> altura . "!";
    
    }


    // Gets e Sets

    public function getNome() {
        return $this -> nome;
    
    }
    
    public function setNome($nome): self {
    
        $this -> nome = $nome;
    
        return $this;
    
    }
    
    public function getEndereco() {
        return $this -> endereco;
    
    }
    
    public function setEndereco($endereco): self {
    
        $this -> endereco = $endereco;
    
        return $this;
    
    }
    
    public function getCidade() {
        return $this -> cidade;
    
    }
    
    public function setCidade($cidade): self {
    
        $this -> cidade = $cidade;
    
        return $this;
    
    }
    
    public function getUf() {
        return $this -> uf;
    
    }
    
    public function setUf($uf): self {
    
        $this -> uf = $uf;
    
        return $this;
    
    }
    
    public function getAltura() {
        return $this -> altura;
    
    }
    
    public function setAltura($altura): self {
    
        $this -> altura = $altura;
    
        return $this;
    
    }

}


// Programa

$pessoa1 = new Pessoa();
$pessoa1 -> setNome("João");
$pessoa1 -> setEndereco("Rua Silva");
$pessoa1 -> setCidade("São Paulo");
$pessoa1 -> setUf("SP");
$pessoa1 -> setAltura(1.80);
print ($pessoa1 -> getApresentacao() . "\n");

$pessoa2 = new Pessoa();
$pessoa2 -> setNome("Maria");
$pessoa2 -> setEndereco("Rua Santos");
$pessoa2 -> setCidade("São Paulo");
$pessoa2 -> setUf("SP");
$pessoa2 -> setAltura(1.70);
print ($pessoa2 -> getApresentacao() . "\n");