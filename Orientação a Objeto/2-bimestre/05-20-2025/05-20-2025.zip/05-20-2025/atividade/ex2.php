<?php

class Aluno {


    // Atributos

    private $nome;
    private $nota1;
    private $nota2;


    // Métodos

    public function getMedia() {

        return ($this -> nota1 + $this -> nota2) / 2;

    }


    // Gets e Sets

    


    public function getNome() {

        return $this -> nome;
    
    }
    
    public function setNome($nome): self {
    
        $this -> nome = $nome;
    
        return $this;
    
    }
    
    public function getNota1() {

        return $this -> nota1;
    
    }
    
    public function setNota1($nota1): self {
    
        $this -> nota1 = $nota1;
    
        return $this;
    
    }
    
    public function getNota2() {

        return $this -> nota2;
    
    }
    
    public function setNota2($nota2): self {
    
        $this -> nota2 = $nota2;
    
        return $this;
    
    }
}

$aluno1 = new Aluno();
$aluno1 -> setNome("João");
$aluno1 -> setNota1(8);
$aluno1 -> setNota2(9);
echo "A média do aluno é: " . $aluno1 -> getMedia() . "\n";

$aluno2 = new Aluno();
$aluno2 -> setNome("Marinbal");
$aluno2 -> setNota1(10);
$aluno2 -> setNota2(4);
echo "A média do aluno é: " . $aluno2 -> getMedia() . "\n";

