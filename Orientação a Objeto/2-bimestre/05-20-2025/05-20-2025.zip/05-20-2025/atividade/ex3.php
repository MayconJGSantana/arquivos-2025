<?php

// Classes

class Livro {


    // Atributos

    private $titulo;
    private $autor;
    private $genero;
    private $numeroPaginas;


    // Gets e Sets

    public function getTitulo() {

        return $this -> titulo;
    
    }
    
    public function setTitulo($titulo): self {
    
        $this -> titulo = $titulo;
    
        return $this;
    
    }
    
    public function getAutor() {
    
        return $this -> autor;
    
    }
    
    public function setAutor($autor): self {
    
        $this -> autor = $autor;
    
        return $this;
    
    }
    
    public function getGenero() {
    
        return $this -> genero;
    
    }
    
    public function setGenero($genero): self {
    
        $this -> genero = $genero;
    
        return $this;
    
    }
    
    public function getNumeroPaginas() {
    
        return $this -> numeroPaginas;
    
    }
    
    public function setNumeroPaginas($numeroPaginas): self {
    
        $this -> numeroPaginas = $numeroPaginas;
    
        return $this;
    
    }

}

$livro1 = new Livro();
$livro1 -> setTitulo("O Físico");
$livro1 -> setAutor("Noah Gordon");
$livro1 -> setNumeroPaginas("592");

$livro2 = new Livro();
$livro2 -> setTitulo("A Biblioteca da Meia-Noite");
$livro2 -> setAutor("Matt Haig");
$livro2 -> setNumeroPaginas("308");

$livro3 = new Livro();
$livro3 -> setTitulo("Ética a Nicômaco");
$livro3 -> setAutor("Aristóteles");
$livro3 -> setNumeroPaginas("392");

$livros = array();

array_push($livros, $livro2);

array_push($livros, $livro3);


$maiorPaginas = $livro1;

for ($i = 2; $i <= 3; $i++) {

    if ($maiorPaginas -> getNumeroPaginas() < $livros[$i - 2] -> getNumeroPaginas()) {

        $maiorPaginas = $livros[$i - 2];

    }

}

var_dump($maiorPaginas);


