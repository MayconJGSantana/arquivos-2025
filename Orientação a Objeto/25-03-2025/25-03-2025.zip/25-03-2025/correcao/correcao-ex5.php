<?php


// Ler os números

$num1 = readline("informe o primeiro número: ");

$num2 = readline("Informe o segundo númeor: ");


// Números divisíveis por 5 do intervalo