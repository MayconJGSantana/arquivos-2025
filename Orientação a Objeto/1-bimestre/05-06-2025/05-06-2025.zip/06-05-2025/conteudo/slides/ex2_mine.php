<?php

class Retangulo {

    public $altura;
    public $base;

    
    function area() {
        $area = $this -> altura * $this -> base;
    }
}