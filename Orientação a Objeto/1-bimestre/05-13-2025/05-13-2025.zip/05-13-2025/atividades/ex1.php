<?php

class Animal {

    public $identificacao;
    public $quantidade_patas;
    public $pele;
    public $nome;

    
    function __construct ($quantidade_patas, $pele, $nome, $identificacao = 0) {

        $this -> identificacao = $identificacao;
        $this -> quantidade_patas = $quantidade_patas;
        $this -> pele = $pele;
        $this -> nome = $nome;

    }


    function emita_som() : string {

        if ($this->nome == "cachorro") {
            return "au au";
        }
        
        else if ($this->nome == "peixe") {
            return "silêncio (não faz som perceptível)";
        }
        
        else if ($this->nome == "gavião") {
            return "chiado agudo";
        }
        
        else if ($this->nome == "cobra") {
            return "ssss";
        }
        
        else if ($this->nome == "gato") {
            return "miau";
        }
        
        else {
            return "Som desconhecido";
        }
        
        
    }

    function movimentacao () : string {

        if ($this->nome == "cachorro") {
            return "Anda";
        }
        
        else if ($this->nome == "peixe") {
            return "Nada";
        }
        
        else if ($this->nome == "gavião") {
            return"Voa";
        }
        
        else if ($this->nome == "cobra") {
            return "Rasteja";
        }
        
        else if ($this->nome == "gato") {
            return "Anda";
        }
        
        else {
            return "Movimentação desconhecida";
        }
        
    }

    function estrutura() : string {

        if ($this->nome == "cachorro") {
            return "                                                  
                                        ##        
                                      ####        
                                      ####        
                                    ########      
                                  ############    
  ##                              ################
  ##                          ##    ##############
  ##                        ######    ##    ####  
  ####################################            
    ##################################            
  ######################################          
  ######################################          
  ####################################            
  ##############  ####################            
  ############        ################            
  ############              ##########            
    ########                  ########            
  ##########                  ##  ##              
  ####  ####                ####  ##              
  ####  ####                ####  ##              
  ####  ####                ####  ##              
  ####  ####                ####  ####            
  ####    ####              ############          
    ##                                            ";
        }
        
        else if ($this->nome == "peixe") {
            return "
                        ############              
--####              ######################        
  ######        ##############################    
  ##########  ##################################  
    ######################################  ######
    ##############################################
    ##############################################
    ##############################################
  ##########  ##################################  
  ######        ############################..    
  ##                ######################        
                        ..##########              
                                                  
                                                  
                                                  
                                                  
                                                  
                                                  ";
        }
        
        else if ($this->nome == "gavião") {
            return "
                ##############                    
              ####################                
            ##########################            
          ################        ######          
        ####################      ##########      
      ########################################    
        ######################################    
        ######################################    
      ##########################                  
      ##  ####################                    
          ##################                      
        ##################                        
        ##################                        
          ################                        
          ####  ##########                        
          ####    ########                        
            ##      ######                        
                        ##                        
                                                  
                                                  
                                                  ";
        }
        
        else if ($this->nome == "cobra") {
            return "
           ###################        
          ########################    
        ############################  
      ###$######         ############ 
      ##$#$####              #########
     ##$##$###                ########
    ##$####$###               ########
   ##$####$####               ########
   ###$##$####               #########
   Ø###$###Ø#               ######### 
   ###$#$###               #########  
    #######               #########   
   #######               #########    
    ####               ##########     
     $               ###########      
    $              ###########        
    $            ###########          
   $           ###########            
  $ $        ###########              
           ###########                
         ###########                  
       ###########                    
     ###########                      
   ###########                        
  ###########                         
";
        }
        
        else if ($this -> nome == "gato") {
            return "
                                ##              ##
                                ####          ####
  ####                          ##################
##########                      ##################
  ##########                    ####  ######  ####
      ######                    ####    ####    ##
        ######                  ##################
        ######        ########    ################
        ######    ############    ##############  
        ######  ################      ########    
        ##########################                
        ############################              
        ####################################      
        ####################################      
        ####################################      
        ############################  ######      
        ########################      ######      
        ######################        ######      
        ####################          ######      
        ######################        ######      
        ########################      ######      
          ######################      ######      ";
        }
        
        else {
            return "Movimentação desconhecida";
        }
        
    }

}

$animal = new Animal(4, "pelo", "cachorro");
print(str_repeat("-", 15) . "1° Animal" . str_repeat("-", 15) . "\n");
print("\t Nome: " . $animal -> nome . "\n");
print("\t Pele: " . $animal -> pele . "\n");
print("\t Quantidade de patas: " . $animal -> quantidade_patas . "\n");
print($animal -> estrutura());

print(str_repeat("\n", 5));

$animal = new Animal(0, "escama", "peixe");
print(str_repeat("-", 15) . "2° Animal" . str_repeat("-", 15) . "\n");
print("\t Nome: " . $animal -> nome . "\n");
print("\t Pele: " . $animal -> pele . "\n");
print("\t Quantidade de patas: " . $animal -> quantidade_patas . "\n");
print($animal -> estrutura());

print(str_repeat("\n", 5));

$animal = new Animal(2, "penas", "gavião");
print(str_repeat("-", 15) . "3° Animal" . str_repeat("-", 15) . "\n");
print("\t Nome: " . $animal -> nome . "\n");
print("\t Pele: " . $animal -> pele . "\n");
print("\t Quantidade de patas: " . $animal -> quantidade_patas . "\n");
print($animal -> estrutura());

print(str_repeat("\n", 5));

$animal = new Animal(0, "escama", "cobra");
print(str_repeat("-", 15) . "4° Animal" . str_repeat("-", 15) . "\n");
print("\t Nome: " . $animal -> nome . "\n");
print("\t Pele: " . $animal -> pele . "\n");
print("\t Quantidade de patas: " . $animal -> quantidade_patas . "\n");
print($animal -> estrutura());


print(str_repeat("\n", 5));

$animal = new Animal(4, "pelo", "gato");
print(str_repeat("-", 15) . "5° Animal" . str_repeat("-", 15) . "\n");
print("\t Nome: " . $animal -> nome . "\n");
print("\t Pele: " . $animal -> pele . "\n");
print("\t Quantidade de patas: " . $animal -> quantidade_patas . "\n");
print($animal -> estrutura());

print(str_repeat("\n", 3));


