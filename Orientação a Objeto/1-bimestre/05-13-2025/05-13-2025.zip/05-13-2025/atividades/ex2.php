<?php

class Pokemon {

    public $nome;
    public $atributo;
    public $experiencia;
    public $pontosVida;
    public $ataque;
    public $defesa;
    public $velocidade;

    
    function __construct() {
        $this -> nome 

    }


    function batalhar() {

    }

    function usarPocoes() {

    }

    function aumentaExperiencia() {

    }

}
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
$reader = new Xlsx();
$spreadsheet = $reader->load('/planilha.xlsx');